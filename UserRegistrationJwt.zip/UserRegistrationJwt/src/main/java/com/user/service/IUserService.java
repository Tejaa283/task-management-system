package com.user.service;

import com.user.model.User;

public interface IUserService {

	Long saveUser(User user);
	
}
