package com.user.service;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.user.model.User;
import com.user.repository.UserRepository;
@Service
public class UserServiceImpl implements IUserService, UserDetailsService {

    @Autowired
    private BCryptPasswordEncoder pswdEncoder;

    @Autowired
    private UserRepository repository;

    @Override
    public Long saveUser(User user) {
        user.setPassword(pswdEncoder.encode(user.getPassword()));
        return repository.save(user).getId();
    }

    public Optional<User> findByUsername(String username) {
        return repository.findByUsername(username);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> opt = findByUsername(username);
        if (opt.isEmpty()) {
            throw new UsernameNotFoundException("User does not exist");
        }
        User user = opt.get();
        return new org.springframework.security.core.userdetails.User(
            username, 
            user.getPassword(),
            user.getRoles().stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList())
        );
    }
}