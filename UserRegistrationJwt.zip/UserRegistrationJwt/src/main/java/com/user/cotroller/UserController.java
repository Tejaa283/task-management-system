package com.user.cotroller;

import java.net.http.HttpHeaders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.jwtuser.JwtUtil;
import com.user.model.User;
import com.user.model.UserRequest;
import com.user.model.UserResponse;
import com.user.service.UserServiceImpl;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserServiceImpl service;

    @Autowired
    private JwtUtil util;

    @Autowired
    private BCryptPasswordEncoder pswdEncoder;

    @PostMapping("/save")
    public ResponseEntity<String> saveUser(@RequestBody User user) {
        long id = service.saveUser(user);
        String body = "User '" + id + "' saved";
        return ResponseEntity.ok(body);
    }

    @PostMapping("/login")
    public ResponseEntity<UserResponse> loginUser(@RequestBody UserRequest request) {
        UserDetails userDetails = service.loadUserByUsername(request.getUsername());
        if (pswdEncoder.matches(request.getPassword(), userDetails.getPassword())) {
            String token = util.generateToken(request.getUsername());
            return ResponseEntity.ok(new UserResponse(token, "Token successfully generated"));
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new UserResponse(null, "Invalid credentials"));
        }
    }
 // Existing endpoints...

    @PostMapping("/validate-token")
    public ResponseEntity<String> validateToken(@RequestHeader("Authorization") String token) {
        // Use the token directly as received from the header

        // Validate the token
        if (util.validateToken(token, util.getUsername(token))) {
            return ResponseEntity.ok("Token is valid");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid or expired token");
        }
    }
}