package com.user.jwtuser;

import java.util.Date;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
@Component
public class JwtUtil {

    @Value("${app.secret}")
    private String secret;

    // Generate token
    public String generateToken(String subject) {
        return Jwts.builder()
                .setSubject(subject)
                .setIssuer("your-app-name")
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(15)))
                .signWith(SignatureAlgorithm.HS512, secret.getBytes())
                .compact();
    }

    // Read claims from the token
    public Claims getClaims(String token) {
        try {
            return Jwts.parser()
                    .setSigningKey(secret.getBytes())
                    .parseClaimsJws(token)
                    .getBody();
        } catch (Exception e) {
            return null;
        }
    }

    // Validate the token with the username and check if it's expired
    public boolean validateToken(String token, String username) {
        String tokenUsername = getUsername(token);
        return (username.equals(tokenUsername) && !isTokenExpired(token));
    }

    // Read subject/username from the token
    public String getUsername(String token) {
        return getClaims(token).getSubject();
    }

    // Check if the token is expired
    public boolean isTokenExpired(String token) {
        Date expDate = getClaims(token).getExpiration();
        return expDate.before(new Date(System.currentTimeMillis()));
    }
}